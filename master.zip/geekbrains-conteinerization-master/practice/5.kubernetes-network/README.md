curl Examples
```
curl -k 1.1.1.1 -L -H "Host: my.company.com"
```
