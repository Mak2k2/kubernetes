**NFS**

Руководство по настройке NFS в облаке VK Cloud Solutions<br>
https://mcs.mail.ru/docs/ru/base/k8s/k8s-pvc/nfs-connection
